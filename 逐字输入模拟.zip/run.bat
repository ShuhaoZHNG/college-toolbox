@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "SCRIPT=%~dp0ghost_typer.py"
if not exist "%SCRIPT%" (
  echo [ERROR] ghost_typer.py not found. Keep run.bat and ghost_typer.py in the same folder.
  pause
  exit /b 1
)

set "GOOD="
set "P1="
set "P2="
for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "P1=%%~i"
for /f "delims=" %%i in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "P2=%%~i"

for %%C in ("!P1!" "!P2!" "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" "C:\Python314\python.exe" "C:\Python313\python.exe" "C:\Python312\python.exe") do (
  if "!GOOD!"=="" (
    if exist "%%~C" (
      "%%~C" -c "import tkinter" >nul 2>&1
      if not errorlevel 1 set "GOOD=%%~C"
    )
  )
)

if "!GOOD!"=="" (
  echo [ERROR] No Python with tkinter found.
  echo Please install Python 3.8+ with the "tcl/tk and IDLE" option enabled.
  pause
  exit /b 1
)

set "PYW=!GOOD:python.exe=pythonw.exe!"
if not exist "!PYW!" set "PYW=!GOOD!"
start "" "!PYW!" "!SCRIPT!"
exit /b 0
